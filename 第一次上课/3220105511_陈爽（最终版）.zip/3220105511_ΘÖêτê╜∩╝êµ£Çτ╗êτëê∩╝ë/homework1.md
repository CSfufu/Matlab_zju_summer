# 运行说明和实验结果展示

## 主代码的展示

![](/Users/csgo/Desktop/截屏2023-07-03 14.14.26.png)

在命令行界面里面分别对应五个功能

## 首先生成一个矩阵

![](/Users/csgo/Desktop/截屏2023-07-03 13.09.35.png)

## 进行转置操作

![](/Users/csgo/Desktop/截屏2023-07-03 13.09.52.png)

![](/Users/csgo/Desktop/截屏2023-07-03 14.18.59.png)

## 输入矩阵的行数和列数

![](/Users/csgo/Desktop/截屏2023-07-03 13.10.07.png)

## 寻找到矩阵中的最大值和最小值

![](/Users/csgo/Desktop/截屏2023-07-03 13.10.14.png)

**找到最大数据**

![](/Users/csgo/Desktop/截屏2023-07-03 14.18.47.png)

**找到最小数据**

![](/Users/csgo/Desktop/截屏2023-07-03 14.18.59.png)

## 通过冒泡排序对矩阵中的元素进行排序

![](/Users/csgo/Desktop/截屏2023-07-03 13.10.23.png)

![](/Users/csgo/Desktop/截屏2023-07-03 14.18.14.png)